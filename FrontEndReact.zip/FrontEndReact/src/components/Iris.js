import React, { useState } from 'react';
import {  TextField ,Button, FormControl, FormGroup, FormControlLabel, Radio,  RadioGroup, FormLabel} from '@material-ui/core';
import SendIcon from '@material-ui/icons/Send';
import DeleteIcon from '@material-ui/icons/Delete';
import Alert from '@material-ui/lab/Alert';
import { makeStyles } from '@material-ui/core/styles';
import axios from './axios'
import "./Churn.css";


const useStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
  },
  formControl: {
    margin: theme.spacing(3),
  },
}));


const Iris = () => {
  const classes = useStyles();
  const [sepalLength, setSepalLength] = useState(0);
  const [sepalWidth, setSepalWidth] = useState(0);
  const [petalLength, setPetalLength] = useState(0);
  const [petalWidth, setPetalWidth] = useState(0);
  const [predicted, setPredicted] = useState(null);

  const sendData = async(e) => {

    e.preventDefault();

    axios.post('/prediction?username=jflorianf;api_key=b0a83748c11e29f5490a128b7a1c8c35011f47bd', {
      "model": "model/60c93bac9193b91733004bfc",
      "input_data":{     
        "SepalLengthCm": sepalLength,
        "SepalWidthCm": sepalWidth,
        "PetalLengthCm": petalLength,
        "PetalWidthCm": petalWidth
          
      }
    }).then((response) => {
      console.log(response.data) 
      isPredicted(response)
      
});
   
  };

  const cleanData = () =>{
    setSepalLength(0)
    setSepalWidth(0)
    setPetalLength(0)
    setPetalWidth(0)
    setPredicted(null)
    
  }

  const isPredicted = (confidence) => {
    setPredicted(confidence.data.output);
  }

  return(
    
    <div class="field">
     <form className="app__form">
       <FormControl className={classes.formControl}>
       <FormGroup>
         <FormLabel component="legend">Sepal length</FormLabel>
        <input className="spinner" type="number" min={0} max={11}  onkeypress="return false"  value={sepalLength} onChange={event => setSepalLength(event.target.value)}/>     
        <FormLabel component="legend">Sepal Width</FormLabel> 
        <input className="spinner" type="number" min={0} max={4385}  onkeypress="return false"  value={sepalWidth} onChange={event => setSepalWidth(event.target.value)}/>     
        <FormLabel component="legend">Petal Length</FormLabel>  
        <input className="spinner" type="number" min={0} max={4546}  onkeypress="return false"  value={petalLength} onChange={event => setPetalLength(event.target.value)}/> 
        <FormLabel component="legend">Petal Width</FormLabel>  
        <input className="spinner" type="number" min={0} max={4546}  onkeypress="return false"  value={petalWidth} onChange={event => setPetalWidth(event.target.value)}/>         
         </FormGroup>
       </FormControl>

      
       <FormControl>
       <Button
        className="button"
        variant="contained"
        color="primary"
        onClick={sendData}
        startIcon={<SendIcon />}
      >
        Send
      </Button>
      <br/>
      <Button
        className="button"
        variant="contained"
        color="secondary"
        onClick={cleanData}
        startIcon={<DeleteIcon />}
      >
        Delete
      </Button>
       </FormControl>
       
  
       {predicted && <Alert 
      className="alert"
      variant="filled"
      severity="success">
     El tipo de flor es: <b>{predicted}</b>
      </Alert>}
      
  
     </form>
    </div>
    )
}




export default Iris
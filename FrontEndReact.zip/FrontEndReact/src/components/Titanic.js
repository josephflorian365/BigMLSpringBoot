import React, { useState } from 'react';
import {  TextField ,Button, FormControl, FormGroup, FormControlLabel, Radio,  RadioGroup, FormLabel} from '@material-ui/core';
import SendIcon from '@material-ui/icons/Send';
import DeleteIcon from '@material-ui/icons/Delete';
import Alert from '@material-ui/lab/Alert';
import { makeStyles } from '@material-ui/core/styles';
import axios from './axios'
import "./Churn.css";


const useStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
  },
  formControl: {
    margin: theme.spacing(3),
  },
}));


const Titanic = () => {
  const classes = useStyles();
  const [clase, setClase] = useState("");
  const [age, setAge] = useState("");
  const [joined, setJoined] = useState("");
  const [survived, setSurvived] = useState(null);

  const sendData = async(e) => {

    e.preventDefault();
    // /prediction?username=julioquispe&api_key=45144bb86790abe56fc4b3a66ca1767bd5581b78
    axios.post('/prediction?username=benjamindiaz&api_key=c25edd529050054c4c20c192e6ba985af559d863', {
      "model": "model/60c938469193b91733004bea",
      "input_data":{     
        "Clase": clase,
        "Joined": age,
        "Age": joined
          
      }
    }).then((response) => {
      console.log(response.data) 
      isSurvived(response)
      
});
   
  };

  const cleanData = () =>{
    setClase("")
    setAge("")
    setJoined("")
    setSurvived("")

    
  }

  const isSurvived = (confidence) => {
    setSurvived(confidence.data.output);
  }

  return(
    
    <div class="field">
     <form className="app__form">
       <FormControl className={classes.formControl}>
         <FormGroup>
        <FormLabel component="legend">Clase</FormLabel>
        <RadioGroup  value={clase} defaultValue="2nd Class" onChange={event => setClase(event.target.value)}>
          <FormControlLabel value="2nd Class" control={<Radio />} label="2nd Class" />
          <FormControlLabel value="No" control={<Radio />} label="No" />   
        </RadioGroup>

        <FormLabel component="legend">Age</FormLabel>
        <RadioGroup  value={age} defaultValue="10-19" onChange={event => setAge(event.target.value)}>
          <FormControlLabel value="10-19" control={<Radio />} label="10-19" />
          <FormControlLabel value="No" control={<Radio />} label="No" />   
        </RadioGroup>

        <FormLabel component="legend">Joined</FormLabel>
        <RadioGroup  value={joined} defaultValue="Cherbourg" onChange={event => setJoined(event.target.value)}>
          <FormControlLabel value="Cherbourg" control={<Radio />} label="Cherbourg" />
          <FormControlLabel value="No" control={<Radio />} label="No" />   
        </RadioGroup>
         </FormGroup>
       </FormControl>

      
       <FormControl>
       <Button
        className="button"
        variant="contained"
        color="primary"
        onClick={sendData}
        startIcon={<SendIcon />}
      >
        Send
      </Button>
      <br/>
      <Button
        className="button"
        variant="contained"
        color="secondary"
        onClick={cleanData}
        startIcon={<DeleteIcon />}
      >
        Delete
      </Button>
       </FormControl>
       
  
       {survived && <Alert 
      className="alert"
      variant="filled"
      severity="success">
     Murió en el titanic: <b>{survived}</b>
      </Alert>}
      
  
     </form>
    </div>
    )
}




export default Titanic
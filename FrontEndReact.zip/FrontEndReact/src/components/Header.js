import React from 'react'
import { AppBar, Toolbar } from "@material-ui/core";
import { Link } from 'react-router-dom'

import "./Nav.css";


export default function Header() {
  const displayDesktop = () => {
    return <Toolbar>
    <div className="nav">
      <ul>
        <li ><Link className="link" to='/'>HOME</Link></li>
        <li ><Link className="link" to='/Digit'>DIGIT</Link></li>
        <li ><Link className="link" to='/Churn'>CHURN</Link></li>
        <li ><Link className="link" to='/Titanic'>TITANIC</Link></li>
        <li ><Link className="link" to='/Iris'>IRIS</Link></li>
      </ul>
      </div>
    </Toolbar>;
  };
  
  return (
    <header>
       <AppBar>{displayDesktop()}</AppBar>
   
  </header>
  );
};
